from . import generic
from .client import Client


@Client._register_endpoint
def update_preset_settings(preset_id, settings, auth_token=None, session=None):
    data = generic.encode_encdata({"presetId": preset_id, "settings": settings})
    return generic.process_response(
        generic.geotastic_api_request(
            session,
            "https://backend03.geotastic.net/v1/settings/updatePresetSettingsV2.php",
            "POST",
            auth_token,
            json={"enc": data},
        )
    )
