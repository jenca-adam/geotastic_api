class GeotasticAPIError(Exception):
    pass


class LobbyError(GeotasticAPIError):
    pass
